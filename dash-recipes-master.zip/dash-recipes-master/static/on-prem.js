window.PLOTLYENV = {
    BASE_URL: 'https://stage.plot.ly'
}
