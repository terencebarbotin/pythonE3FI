from flask import Flask

server = Flask(__name__)
