import sys
sys.path.append("..")
from app import app
from dash import Input, Output, ctx
from model.choro_map_model import get_choro_map_model
from model.years import YEARS

# On connecte l'intervalle avec le years-slider de la map
@app.callback( Output('years-slider-map', 'value'),
            [Input('interval-map', 'n_intervals')])
def on_tick(n_intervals):
    if n_intervals is None: return 0
    return YEARS[(n_intervals+1)%len(YEARS)]

# On met à jour le H1 de la map en fonction de l'année
@app.callback(
    Output(component_id="maph2", component_property='children'),
    [Input(component_id='years-slider-map', component_property='value')]
)
def update_map_h2(input_value):
    return 'Consommation d\'électricité des communes franciliennes en ' + str(input_value)
# On connecte le bouton "play"/"pause" de la map avec l'intervalle de la map
@app.callback( Output('interval-map', 'disabled'),
                Input('play-map','n_clicks'),
                Input('pause-map','n_clicks')
            )
def play_hist(play, pause):
    if ('play-map' == ctx.triggered_id): 
        print("Play")
        return False
    elif ('pause-map' == ctx.triggered_id):
        print("Pause")
        return True
    else: return True
    
# On connecte le years slider avec la map choropleth
@app.callback(
    Output(component_id='map', component_property='figure'), # (1)
    [Input(component_id='years-slider-map', component_property='value')], # (2)
)
def update_map(input_value): 
    return get_choro_map_model(year = input_value)
            