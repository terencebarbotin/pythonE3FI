import sys
sys.path.append("..")
from app import app
from dash import Input, Output, ctx
from model.histogram_model import get_hist_model
from model.years import YEARS

# On connecte le years-slider avec l'histogramme
@app.callback(
    Output(component_id='histogram', component_property='figure'), 
    [Input(component_id='years-slider-hist', component_property='value')] 
)
def update_histogram(input_value): 
    print(input_value)
    return get_hist_model(year = input_value)
# On connecte l'intervalle avec le years-slider de la map
@app.callback( Output('years-slider-hist', 'value'),
            [Input('interval-hist', 'n_intervals')])
def on_tick(n_intervals):
    if n_intervals is None: return 0
    return YEARS[(n_intervals+1)%len(YEARS)]

# On connecte le bouton "play"/"pause" de la map avec l'intervalle de la map
@app.callback( Output('interval-hist', 'disabled'),
                Input('play-hist','n_clicks'),
                Input('pause-hist','n_clicks')
            )
def play_hist(play, pause):
    if ('play-hist' == ctx.triggered_id): 
        print("Play")
        return False
    elif ('pause-hist' == ctx.triggered_id):
        print("Pause")
        return True
    else: return True