
# Watt Project Dashboard

Le Watt Project Dashboard est une application développée en Python à l'aide des modules Dash et plotly. Il permet de visualiser la consommation électrique française sur les dix dernières années.


## User Guide

Pour déployer le Watt Project Dashboard sur votre machine, suivre ces étapes :
- cloner le projet à l'aide de git dans un terminal :
	```
	git clone https://git.esiee.fr/anges/watt_project.git
	```
- Se placer dans le dossier du projet :
	```
	cd watt_project/
	```
- Installer les modules requis : 
	```
	python -m pip install -r requirements.txt
	```
- Lancer l'application : 
	- Windows : 
	```
	python main.py
	```
	- MacOs/Linux : 
	```
	python3 main.py
	```
Maintenant, il faut s'armer de patience et attendre quelques minutes, le temps que l'application récupère l'ensemble des données auprès de l'API... 

Vous pouvez en suivre la progression dans votre terminal.

![enter image description here](https://git.esiee.fr/anges/watt_project/-/raw/main/images/progress.png)

Une fois l'application initialisée, vous pouvez y accéder en tapant dans votre navigateur :
```
http://127.0.0.1:8050
```
ou simplement en cliquant [ici](http://127.0.0.1:8050).
##  Rapport d'analyse

Watt Project Dashboard exploite plusieurs ensembles de données.

Le premier est fourni par La Poste et permet notamment d'associer chaque Ville à un code commune, ainsi qu'à ses coordonnées GPS. Il est disponible sur ce lien : [Base officielle des codes postaux](https://www.data.gouv.fr/fr/datasets/base-officielle-des-codes-postaux/). Je l'utilise au format CSV.

Le second est, lui, fourni par l'agence ORE. Il s'agit d'une API qui permet notamment d'associer à chaque commune des informations sur sa consommation d'électricité annuelle. Il est disponible sur ce lien : [Consommation annuelle d'électricité et gaz par commune et par secteur d'activité](https://www.data.gouv.fr/fr/datasets/consommation-annuelle-delectricite-et-gaz-par-commune-et-par-secteur-dactivite/). 

Le dashboard est constitué de trois éléments : 
### Histogramme
Représentant le nombre de communes consommant x MWh d'électricité pour une année donnée. Un slider est disponible afin de pouvoir comparer les statistiques d'une année à une autre. Celui-ci va de 2011 à 2021. On observe ainsi que, quelle que soit l'année, de nombreuses communes françaises consomment moins de 1500 MWh d'électricité par an (9621 en 2011, 9763 en 2021). Néanmoins, elles sont aussi très nombreuses à consommer bien plus. 

![enter image description here](https://git.esiee.fr/anges/watt_project/-/raw/main/images/histo.png)
### Carte choroplèthe
Représentant la consommation d'électricité des communes franciliennes en fonction des années. Plus une commune est colorée en foncée, plus elle consomme d'électricité. On remarque ainsi que Paris et sa petite couronne sont relativement énergivores sur le plan électrique, contrairement aux communes plus reculées tels que celles appartenant à l'Est de la Seine-et-Marne. Aussi, on ne distingue pas d'évolution majeure de consommation suivant les années.

![enter image description here](https://git.esiee.fr/anges/watt_project/-/raw/main/images/choropleth.png)

### Une carte avec des cercles
Représentant les villes les plus consommatrices d'électricité en France. Plus les cercles sont gros et foncés, plus la ville correspondante consomme de l'électricité. Sans surprise, on retrouve de grandes villes telles que Paris, Toulouse, Nice et Lille. On y retrouve aussi d'autres villes, consommant l'électricité de manière plus modérée mais tout de même bien au-dessus de la moyenne : Noisy-Le-Grand, Argenteuil, Mulhouse... Les valeurs de consommation indiquées représentant l'ensemble de la consommation d'une commune de 2011 à 2021.

![enter image description here](https://git.esiee.fr/anges/watt_project/-/raw/main/images/conso_map.png)

## Developer Guide

  ### Architecture du code

Ce projet est scindé selon un pattern MVC (Model-View-Controller) : 

#### Controller
Reçoit les inputs de l'utilisateur, et met à jour les données à afficher dans le Model.

 - choro_map_controller.py
 - histogram_controller.py
#### Model

Instancie les données, et les communique à la View. Elles sont mises à jour par le Controller.

- choro_map_model.py
- histogram_model.py
- datas.py
- years.py
- bc_map_model.py
#### View

Représente l'état actuel du Model, et donc ce qui sera affiché à l'utilisateur. Chaque composant (map choroplèthe, 2ème map, histogramme) est rassemblé dans layout.py.

- bc_map_layout.py
- choro_map_layout.py
- histogram_layout.py
- layout.py

#### Architecture du code

```mermaid

graph TD

A[Watt Projet] --> B[main.py]

B --> |Launch app| C[app.py]

C --> D[vue.layout]

D --> E(create_layout)

E --> F[histogram_layout.py]

F --> G(get_hist_layout)

G --> R{User}

E --> H[choro_map_layout.py]

H --> I(get_choro_map_layout)

I --> D

E --> J[bc_map_layout.py]

J --> K(get_bc_map_layout)

K --> D

S --> |Give data| L[choro_map_model.py]
L[choro_map_model.py] --> |Ask data| S
M[choro_map_controller.py]--> |Update model|L
L --> |Update layout|H
M --> |Ask data| S

N[histogram_model.py] --> |Ask data| S
S -->|Give data| P
P --> |Ask data|S
O[histogram_controller.py] --> |Update model| N
N --> |Update layout|F

O --> |Ask data| S[datas.py]
S --> |Give data|N
P[bc_map_model.py] -->|Update layout| J

R --> |Input| M

R --> |Input| O

D --> |Display Dashboard| R



```

### Extension du code

Pour étendre le code de cette application, et donc rajouter d'autres composants Plotly, il est nécessaire d'ajouter de nouveaux modèles, vues et contrôleurs en suivant la structure de l'application.

Par exemple :

> *Je souhaite rajouter un nouveau composant px.scatter, comment faire ?*

 1. Modèle : Créez une fonction dans un nouveau fichier .py dans le dossier `model` qui génère les données à afficher sur le graphique `px.scatter`. Cette fonction peut utiliser des données stockées dans un fichier .CSV par exemple, ou bien des données déjà initialisées dans le module `model.datas`. Assurez-vous de retourner les données sous forme de DataFrame Pandas afin de pouvoir les utiliser avec `px.scatter`.

```{python}
import plotly.express as px

def get_scatter_model():
	fig  =  px.scatter(
	x = [1,2,3,4,5,6],
	y = [2,4,6,8,10,12],
		)
```

 2. Vue : Créez une fonction dans un nouveau fichier .py dans le dossier `vue` qui utilise la fonction du modèle pour obtenir les données et crée un objet `px.scatter` en utilisant ces données. Assignez cet objet à une variable et retournez-le afin de pouvoir l'utiliser dans le controller. Lui assigner un id afin de pouvoir l'identifier dans le contrôleur. 

```{python}
from dash import html, dcc
from model.scatter_model import get_scatter_model

def get_scatter_layout():
	return  html.Div(
		dcc.Graph(
		id =  "scatter"
		)
	)
```

Enfin, ne pas oublier d'ajouter le composant vue dans le fichier `layout.py`.

```{python}
from dash import html
from vue.histogram_layout import  get_hist_layout
from vue.choro_map_layout import  get_choro_map_layout
from vue.bc_map_layout import  get_bc_map_layout
from vue.scatter_layout import get_scatter_layout

def  create_layout():
	return html.Div(
		children = [
		# CSS
		html.Link(rel="stylesheet", href="assets/style.css"),
		# Titre de la page
		html.H1(
		children="Dashboard - Consommation d'électricité des communes françaises",
		style = {'font-family': 'Helvetica'},
		),
		# html.Div de l'Histogramme
		get_hist_layout(),
		# html.Div de la map choroplèthe
		get_choro_map_layout(),
		# html.Div de la scatter_mapbox
		get_bc_map_layout(),
		# html.Div de px.scatter
		get_scatter_layout(),
		]
	)
```

 3. Contrôleur : Dans le dossier `controller`, créez un nouveau fichier .py dans lequel vous rajoutez les différentes fonctions liées aux intéractions avec l'utilisateur. Ex : `@app.callback` pour un slider. 

Il est de plus recommandé de suivre les conventions de nommage et de style de code existantes afin de maintenir une bonne lisibilité et une bonne organisation du code.
