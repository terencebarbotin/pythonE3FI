from controller.choro_map_controller import app
import controller.histogram_controller


if __name__ == '__main__':
    # Lance l'app
    app.run_server(debug=True)

