from dash import Dash, dcc, html
import dash_bootstrap_components as dbc

from vue.layout import create_layout
from model.datas import ncc_2020

# On initialise l'app, afin un thème dbc.themes.SOLAR
app = Dash(__name__,external_stylesheets=[dbc.themes.SOLAR])

# On initialise le layout de l'application
app.layout = create_layout()

