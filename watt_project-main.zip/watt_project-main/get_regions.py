import requests
import json
import pandas as pd

# URL de l'API pour récupérer les données correspondants aux régions françaises
api_url="https://geo.api.gouv.fr/regions"

# Envoi d'une requête GET à l'API
response = requests.get(api_url)

# Transformation du contenu de la réponse en un df pandas
regions_df = pd.read_json(response.text)
