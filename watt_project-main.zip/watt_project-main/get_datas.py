import requests
import json
import get_regions
import pandas as pd

# On parcourt le dataframe code_communes pour associer la Conso_totale aux bonnes coordonnées GPS.
df_cc = pd.read_csv('data/new_code_communes_bis.csv', delimiter=";")

if(not ("Conso_totale_2011" in df_cc.columns)):
    # On essaye d'obtenir la consommation totale pour chaque année
    for year in range(2011,2022):
        api_url = "https://opendata.agenceore.fr/api/records/1.0/search/?dataset=conso-elec-gaz-annuelle-par-secteur-dactivite-agregee-commune&q=&rows=10000&facet=operateur&facet=annee&facet=filiere&facet=libelle_commune&facet=code_departement&facet=libelle_region&facet=code_postal&refine.filiere=Electricit%C3%A9&refine.annee="+str(year)+"&refine.code_region="
        dict_all = {}

        # On tente d'obtenir la consommation totale pour chaque région de l'année donnée
        for index, region in get_regions.regions_df.iterrows():
            print("Year", year, "/ 2021 : Getting regions... (", index+1, "/", len(get_regions.regions_df),")")
            response_reg = requests.get(api_url+str(region['code']))
            data_reg = json.loads(response_reg.text)
            df_reg = pd.DataFrame(data_reg['records'])
            d_reg = { row['fields']['code_commune']: row['fields']['consototale'] for index, row in df_reg.iterrows()}
            dict_all.update(d_reg)
            

        
        # On parcourt toutes les lignes du dataframe df_cc contenant l'ensemble des consommations pour chaque commune françaises
        for index, row in df_cc.iterrows(): 
            
            # On récupère la valeur de Conso_totale_x pour la commune correspondant à la ligne courante (où x est un élément de YEARS)
            # à partir du dictionnaire dict_all et on l'assigne à la colonne Conso_totale_x de df_cc pour la ligne courante
            df_cc.loc[index, 'Conso_totale_'+str(year)] = dict_all.get(row['Code_commune_INSEE'])
            # On affiche un message dans la console pour suivre l'avancement du traitement
            print("Year", year, "/ 2021 : Getting consommation... (",index+1,"/",len(df_cc.index),")")

        # Add it to a new csv file
        df_cc.to_csv("data/new_code_communes_bis.csv", index = False, sep=";")
        df_cc.to_csv("data/datas.csv", index = False, sep=";")