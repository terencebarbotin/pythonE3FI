from dash import html, dcc
import sys
sys.path.append("../watt_project_mvc")
from model.bc_map_model import get_bc_map_model

def get_bc_map_layout():
    """
    Retourne un élément Div html de Dash contenant un titre et un graphique Plotly (scatter_mapbox) 
    montrant les emplacements des plus gros consommateurs sur une carte. 
    La carte affiche la consommation totale (MwH) de chaque ville en France de 2011 à 2021,
    avec la taille et la couleurs des cercles indiquant le niveau de consommation.

    Returns:
        Div: Dash HTML Div
    """
    return html.Div(
                id='map-biggest-cons-container',
                children=[
                # Titre de la map
                html.H2(
                    children=f'Villes les plus consommatrices d\'électricité en France (2011 → 2021)',
                    style={'textAlign': 'center','font-family' : 'sans-serif' }
                ),
                # On affiche la map
                dcc.Graph(
                    figure = get_bc_map_model(),
                    style={'height':'50em', 'width' : '70%','margin-right':'auto','margin-left':'auto'}
                ),
                    ],
                style={ 'width' : '92%','margin-right':'auto','margin-left':'auto'}
            )