from dash import html
from vue.histogram_layout import get_hist_layout
from vue.choro_map_layout import get_choro_map_layout
from vue.bc_map_layout import get_bc_map_layout

def create_layout():
    """
    Retourne un élément Div HTML de Dash contenant un titre, un élément de style,
    et les éléments Div HTML retournés par les fonctions get_hist_layout(),
    get_choro_map_layout() et get_bc_map_layout(). Ces éléments sont tous affichés sur la même 
    page.

    Returns:
        Div: Dash Div HTML
    """
    return html.Div(
        children = [
            # CSS
            html.Link(rel="stylesheet", href="assets/style.css"),
            
            # Titre de la page
            html.H1(
                children="Dashboard - Consommation d'électricité des communes françaises",
                style = {'font-family': 'Helvetica'},
                ),
            
            # html.Div de l'Histogramme 
            get_hist_layout(),
            # html.Div de la map choroplèthe
            get_choro_map_layout(),
            # html.Div de la scatter_mapbox
            get_bc_map_layout()
        ]
    )