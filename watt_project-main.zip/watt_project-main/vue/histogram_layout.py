from dash import html, dcc
import dash_bootstrap_components as dbc
import sys
sys.path.append("../watt_project_mvc")
from model.years import YEARS

def get_hist_layout():
    """
    Retourne un élément Div HTML de Dash contenant un titre, un curseur, un histogramme, un bouton
    "Play", et un bouton "Pause". L'histogramme montre la consommation d'électricité des communes françaises pour 
    l'année spécifiée par le curseur. L'histogramme est mis à jour en continu lorsque le bouton "Play" 
    est activé, et s'arrête lorsque le bouton "Pause" est activé.

    Returns:
        Div: Dash Div HTML
    """
    return html.Div(
        id='hist-container',
                children=[    
                    # Titre de l'histogramme         
                    html.H2(
                        id = "histh1",
                        children=f'Consommation d\'électricité des communes françaises en 2011',
                        style={'textAlign': 'center','font-family' : 'sans-serif' }
                    ),
                    # Slider de l'histogramme
                    html.Label('Year'),

                    dcc.Slider(
                        id = "years-slider-hist",
                        min = min(YEARS),
                        max = max(YEARS),
                        step= 1,
                        value=min(YEARS),
                        marks={
                            str(year): {
                                "label": str(year),
                                "style":{"color": "#7fafdf"},
                            }   
                            for year in YEARS
                        },
                    ),
                    # Graphique de l'histogramme
                    dcc.Graph(
                        id='histogram',
                    ),
                    # On initialise l'interval lié à l'histogramme
                    dcc.Interval(
                        id = 'interval-hist',
                        interval = 1*1000,
                        n_intervals=0,
                        disabled = True,
                    ),
                    # Bouton Play
                    dbc.Button(
                        children='Play',
                        color = "success",
                        className = "me-3",
                        id = 'play-hist',
                        n_clicks = 0,
                    ),
                    # Bouton Pause
                    dbc.Button(
                        children='Pause',
                        color= "warning",
                        className = "me-3",
                        id = 'pause-hist',
                        n_clicks = 0,
                    )
                ],
        style={'margin-left':'4%','display' : 'inline-block','width':'45%','textAlign': 'center','font-family' : 'sans-serif' }
    )