from dash import html, dcc
import dash_bootstrap_components as dbc
import sys
sys.path.append("../watt_project_mvc")
from model.years import YEARS

def get_choro_map_layout():
    """
    Retour un élément Div HTML de Dash contenant un titre, un slider, une carte choroplèthe,
    un bouton "Play", et un bouton "Pause". Le graphique est une carte montrant la consommation d'électricité
    des communes franciliennes pour l'année spécifiée par le curseur. La carte est mise à jour
    en continu lorsque le bouton "Play" est activé, et s'arrête lorsque le bouton "Pause" est activé.

    Returns:
        Div: Dash Div HTML
    """
    return html.Div(
                id='map-container',
                children=[
                # Titre de la map
                html.H2(
                    id = "maph2",
                    children=f'Carte de consommation d\'électricité des communes franciliennes en 2012',
                    style={'textAlign': 'center','font-family' : 'sans-serif' }
                ),
                # Slider de la map
                html.Label('Year'),
                dcc.Slider(
                    id = "years-slider-map",
                    min = min(YEARS),
                    max = max(YEARS),
                    step= 1,
                    value=min(YEARS),
                    marks={
                        str(year): {
                            "label": str(year),
                            "style":{"color": "#7fafdf"},
                        }   
                        for year in YEARS
                    },
                ),
                # On affiche la map
                dcc.Graph(
                    id="map"
                ),
                # On initialise l'interval de la map
                dcc.Interval(
                    id = 'interval-map',
                    interval = 1*1000,
                    n_intervals=0,
                    disabled = True,
                ),
                # Bouton play de la map
                dbc.Button(
                    children='Play',
                    id = 'play-map',
                    color = "success",
                    className = "me-3",
                    n_clicks = 0,
                ),
                # Bouton pause de la map
                dbc.Button(
                    children='Pause',
                    color = "warning",
                    id = 'pause-map',
                    className = "me-3",
                    n_clicks = 0,
                )
                
                    ],
                    style={'margin-left':'2%','display' : 'inline-block','width':'45%', 'textAlign': 'center','font-family' : 'sans-serif' }
            )