import plotly.express as px
from model.datas import ncc_2020
from model.years import YEARS
import pandas as pd
import json

# Crée une liste de colonnes à partir de la liste YEARS
cols = ['Conso_totale_'+str(year) for year in YEARS]
# On crée une colonne Conso_totale_ALL_YEARS qui contient la somme de toutes les colonnes Conso_totale_x (x : élément de YEARS)
ncc_2020['Conso_totale_ALL_YEARS'] = ncc_2020[cols].sum(axis=1)

# On crée un dataframe afin de stocker les informations sur les villes les plus consommatrices d'électricité
biggest_consumers_df = pd.DataFrame(columns = ['Code_commune_INSEE', 'Nom_commune', 'Conso_totale_ALL_YEARS','coordonnees_gps',])

# On parcourt toutes les lignes du dataframe ncc_2020 et on ajoute une ligne au dataframe biggest_consumers_df
# si la consommation totale de la ville est >= 4000000
for index, row in ncc_2020.iterrows():
    if(int(row['Conso_totale_ALL_YEARS']) >= 4000000):
        biggest_consumers_df.loc[index] = row
# On sépare les coordonnées GPS en deux colonnes lat et lon
biggest_consumers_df[['lat', 'lon']] = biggest_consumers_df.coordonnees_gps.str.split(",", expand=True)

# On supprime la colonne coordonnes GPS afin de la remplacer par les colonnes 'lat' et 'lon'
biggest_consumers_df.drop(columns=['coordonnees_gps'])

# On convertir les colonnes en float afin de pouvoir les utiliser avec Plotly.
biggest_consumers_df['lat'] = biggest_consumers_df['lat'].astype(float)
biggest_consumers_df['lon'] = biggest_consumers_df['lon'].astype(float)

biggest_consumers_df['Conso_totale_ALL_YEARS'] = biggest_consumers_df['Conso_totale_ALL_YEARS'].astype(float)


def get_bc_map_model():
    """
    Retourne un objet plotly (scatter mapbox) utilisant mapbox. 
    Le graphique met en évidence les villes les plus consommatrices d'électricité en France,
    avec des cercles de tailles et couleurs différentes en fonction de leur consommation entre
    les années 2011 et 2021.

    Returns:
        scatter_mapbox: Graphique Plotly
    """
    fig = px.scatter_mapbox(
    biggest_consumers_df,
    size = "Conso_totale_ALL_YEARS",
    color_continuous_scale="Blues",
    range_color=(4000000, 13000000),
    size_max = 70,
    center = {'lat':46.71109,'lon':1.7191036},
    opacity=0.3,
    color = "Conso_totale_ALL_YEARS",
    lat = biggest_consumers_df.lat,
    lon = biggest_consumers_df.lon,
    labels={'Conso_totale_ALL_YEARS':'Consommation (MwH)'},
    hover_name="Nom_commune",
    template="plotly_dark",
    mapbox_style="carto-darkmatter",
    zoom=5
    )
    fig.update_layout(
        mapbox_accesstoken = open(".mapbox_token").read(),
        margin={"r":0,"t":0,"l":0,"b":0}
    )
    return fig

