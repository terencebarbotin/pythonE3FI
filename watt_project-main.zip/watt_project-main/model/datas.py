import pandas as pd 
import get_datas

ncc_2020 = pd.read_csv("data/new_code_communes_bis.csv",
                            dtype={"Code_commune_INSEE": str}, sep=";")