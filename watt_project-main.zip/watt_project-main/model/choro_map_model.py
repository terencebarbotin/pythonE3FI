import plotly.express as px
from model.datas import ncc_2020
from model.years import YEARS
import json

def get_choro_map_model(year):
    """
    Retourne un graphique Plotly qui est une carte choroplèthe créée à l'aide de Mapbox.
    La carte montre la consommation totale (MwH) de chaque commune francilienne dans l'année spécifiée,
    avec une couleur indiquant le niveau de consommation.

    Args:
        year (int): L'année pour laquelle les données de consommation sont affichées

    Returns:
        choropleth_mapbox_: Graphique Plotly carte choroplèthe
    """
    with open('data/idf.geojson') as response:
        communes = json.load(response)
    fig = px.choropleth_mapbox(ncc_2020, geojson=communes,
                                locations='Code_commune_INSEE', 
                                color="Conso_totale_"+str(year),
                                featureidkey='properties.insee_com',
                                color_continuous_scale=[(0, "#6efad4"), (0.05, "#63f2d3"), (0.1, "#5aebd2"), (0.15, "#51e3d0"), (0.2, "#48dbcf"),(0.25, "#41d3cc"),(0.3, "#3ccbc9"),(0.35, "#37c3c6"), (0.4, "#34bcc2"),(0.45, "#37c3c6"),(0.5, "#33b4be"),(0.55, "#32acb9"),(0.6, "#33a4b4"),(0.65, "#349caf"),(0.7, "#3695a9"),(0.75, "#388da3"),(0.8, "#39859c"),(0.85, "#3b7e95"),(0.9, "#3c768e"),(0.95, "#3d6f87"),(1, "#3d687f")],
                                range_color=(0, 90000),
                                mapbox_style="carto-darkmatter",
                                zoom=7.5, center = {'lat':48.690236,'lon':2.498065},
                                opacity=0.5,
                                labels={'Conso_totale_'+str(year):'Consommation (MwH)'},
                                template="plotly_dark"
                                )
    fig.update_layout(
        mapbox_accesstoken = open(".mapbox_token").read(),
        margin={"r":0,"t":0,"l":0,"b":0}
    )
    return fig