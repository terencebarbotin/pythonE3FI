import plotly.express as px
from model.datas import ncc_2020
from model.years import YEARS

def get_hist_model(year):
    """`
    Retourne un graphique Plotly (histogramme) qui montre la distribution des consommations
    parmi les communes françaises dans l'année spécifiée (2011-2021).`

    Args:
        year (int): L'année dont on veut afficher la consommation 

    Returns:
        histogram: Histogramme
    """
    fig = px.histogram(ncc_2020, x = ['Conso_totale_'+str(year)], labels = 
                    {
                        'Conso_totale_'+str(year) : "kwH consommés",
                    }
                    , text_auto=True
                    , color_discrete_sequence=px.colors.qualitative.Pastel
                    , barmode= "group"
                    , template ="plotly_dark"
                    , range_x = ['0', "45000"], range_y = ["0","5000"], nbins = 5000).update_layout(xaxis_title = "Consommation totale (en MwH)",yaxis_title = "Nombre de communes", bargap=0.2,)
    fig.update_layout(
        margin={"r":20,"t":20,"l":20,"b":20}
    )
    return fig